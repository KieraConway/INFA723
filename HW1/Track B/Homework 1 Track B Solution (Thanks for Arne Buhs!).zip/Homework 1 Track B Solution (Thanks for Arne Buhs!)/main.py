import random, string, sys
from cipher import Cipher
from qgram import QgramDistr

def main():
    if (len(sys.argv) != 2):
        print(f"Usage: python3 {sys.argv[0]} <cipherInputFile>")
        exit(1)
    
    cipherFileName = sys.argv[1]
    
    # Create Cipher instance, holding ciper input. Will be used for decoding.
    cipherInp = Cipher(cipherFileName)
    
    # Ask user for plaintext language
    print("Which language do you expect the plainText to be in?")
    print("[1] = English")
    print("[2] = Spanish")
    langNo = input("Please enter number: ")
    if (langNo == "1"):
        qgramDistr = QgramDistr("qgram_data/english_quadgrams.txt")        
    elif (langNo == "2"):
        qgramDistr = QgramDistr("qgram_data/spanish_quadgrams.txt")
    else:
        print("Not a valid input")
        exit()
    
    # Ask user whether to do any changes to the cipherText before decrypting
    print("\nDo you want to do any changes to the cipherText before decrypting?")
    print("[1] = No")
    print("[2] = Reverse ciphertext")
    transpoNo = input("Please enter number: ")
    if (transpoNo == "1"):
        pass
    elif (transpoNo == "2"):
        cipherInp.reverseCipher()
    else:
        print("Not a valid input")
        exit()

    print("\nStarting decryption process in infinite loop. Press CTRL+C to quit.\n")
    
    # maxKey keeps track of the currently overall best key. 
    # Initialize it to a random key as starting point
    maxKey = list(string.ascii_lowercase)
    keyLen = len(maxKey)
    random.shuffle(maxKey)
    # Decode ciphertext with generated key (as starting point)
    maxPlaintext = cipherInp.decode(maxKey)
    # Initialize score of starting point key
    maxScore = qgramDistr.score(maxPlaintext)

    """ Decryption algorithm idea from http://www.practicalcryptography.com/cryptanalysis/stochastic-searching/cryptanalysis-simple-substitution-cipher/.
    Choose a random starting key. Decode the cipherText and score the plainText result (using qgram fitness score for the target language).
    Then exchange 2 random chars in the key. Score the decoded result again. If score is better than previous localMaxScore, continue algorithm with this key, otherwise
    discard it and continue with previous key.
    After 2000 iterations (each swapping two random chars in the key), a local maximum has been found. If this has been the best overall result so far (stored in maxScore),
    we replace the global maxScore/maxKey. We then repeat the whole algorithm to find a new localMaxmimumKey, based on a new random starting key.
    This algorithm runs until the user ends it by pressing CTRL+C"""
    
    # cnt = 0
    while True:
        # cnt = cnt + 1
        i = 0
        localMaxKey = maxKey.copy()
        random.shuffle(localMaxKey)
        localMaxPlaintext = cipherInp.decode(localMaxKey)
        localMaxScore = qgramDistr.score(localMaxPlaintext)

        while (i < 2000):
            # Create new key, swapping two chars randomly
            curKey = localMaxKey.copy()
            pos1 = random.randint(0, keyLen-1)
            ## (For the pos2, make sure it's not the same as pos1)
            while ((pos2 := random.randint(0, keyLen-1)) == pos1):
                pass
            curKey[pos1], curKey[pos2] = curKey[pos2], curKey[pos1]

            curPlaintext = cipherInp.decode(curKey)
            curScore = qgramDistr.score(curPlaintext)

            if (curScore > localMaxScore):
                localMaxKey = curKey
                localMaxPlaintext = curPlaintext
                localMaxScore = curScore
                # Reset counter
                i = 0
            else:
                i = i + 1
        
        if (localMaxScore > maxScore):
            maxScore = localMaxScore
            maxKey = localMaxKey
            maxPlaintext = localMaxPlaintext
            print("***New max score***")
            print(f"Curr decryption key (score={maxScore}): {maxKey}")
            print(f"Curr plaintext: {''.join(maxPlaintext)}")
            """ Note: The following commented-out code could be used if there exists a plainText deciphering
            that has a slightly better score than the actual plainText. Not needed in our case. """
            # elif (localMaxScore > 1.05*maxScore and cnt > 20):
            #     print("***To be considered (not max but close) ***")
            #     print(f"Curr key (with score={localMaxScore}): {localMaxKey}")
            #     print(f"Curr plaintext: {''.join(localMaxPlaintext)}")


if __name__ == "__main__":
    main()