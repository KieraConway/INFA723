import math

# Distribution data and idea taken from http://www.practicalcryptography.com/cryptanalysis/text-characterisation/quadgrams/
# Alternative way for scoring would be to use actual words statistics (more difficult because spaces are usually eliminated)
class QgramDistr:
    """ Stores distribution of qgrams in target language. Provides score() method to calculate
    score of how good a given plaintext fits that qgram distribution. """
    def __init__(self, inputFileName):
        """ Create a hashmap that maps qgramString to log10(p) with
        p = probability that the qgram occurs (in english language texts) """
        self.qgramMap = {}
        with open(inputFileName) as f:
            # I adjusted the input files to store the total number of qgrams in the first line
            # This has better performance than requiring two passes over the map at each run
            self.totalCnt = int(f.readline())
            for line in f:
                qgram, cnt = line.split(" ")
                # Store log10(prob(qgram))
                self.qgramMap[qgram.lower()] = math.log(int(cnt) / self.totalCnt, 10)
        # Store minValue used for qgrams with cnt=0
        self.floor = math.log(0.01/self.totalCnt, 10)

    def score(self, plainText):
        """ Iterate over qgrams of the provided plainText and calculate the
        sum of the logarithmic probabilites for each qgram based on the instance's
        qgram distribution. """
        # Remove all non-alpha characters
        plainText = "".join([ch for ch in plainText if ch.isalpha()])
        logSum = 0
        for i in range(len(plainText) - 3):
            qgram = plainText[i:i+4]
            logSum = logSum + self.qgramMap.get(qgram, self.floor)
        return logSum

# # The following code was just for testing
# if __name__ == "__main__":
#     from cipher import Cipher
#     import string
#     import random
#     newDistr = QgramDistr("english_quadgrams.txt")
#     cipher = Cipher("cipherInput.txt")
#     orgKey = list(string.ascii_lowercase)
#     decoded = cipher.decode(orgKey)
#     print(decoded)
#     print(f"Score org: {newDistr.score(decoded)}")
#     random.shuffle(orgKey)
#     decoded = cipher.decode(orgKey)
#     newDistr.score(decoded)
#     print(f"Score shuffled: {newDistr.score(decoded)}")