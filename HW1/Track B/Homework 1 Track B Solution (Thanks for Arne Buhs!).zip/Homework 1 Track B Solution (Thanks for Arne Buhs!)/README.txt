1) How to run the program, e.g., usage of program?
Run: python3 main.py <cipherInputFile>
There are two things the user can choose at runtime. 1) The target language. 2) Whether to do any changes on the cipherText before decryption.

Example for tweet1:
Run: python3 main.py cipher_input/cipherInp1.txt 
Enter at runtime:
"1" (for English as target language)
"1" (To not do any changes on ciphertext before decryption)

You can choose files cipher_input/cipherInp2.txt and cipher_input/cipherInp3.txt to decrypt the other tweets.
Tweet2: Target Language is English and the cipherText needs to be reversed before decryption
Tweet3: Target language is Spanish (no changes to cipherText to be done before encryption)

2) What is the expected output when running the program?
After asking you for the above mentioned input, the program will run in an infinite loop trying to decrypt the provided cipherText.
It will continuously print the current best Key/Score/PlainText output, whenever finding a better-scored decrypted plaintext.
It runs in an infinite loop until the user presses CTRL+C, when satisfied with the result.

On my computer, decryption of tweet1 can sometimes take some time (up to a minute), while tweet2 and tweet3 are usually decrypted correctly within a few seconds.

FYI: The scores of the correct plaintexts for the tweets are:
    - Tweet1: -431.1
    - Tweet2: -478.6
    - Tweet3: -447.2
Note: I have run the decryption process very often and did not encounter any (wrong) decrypted plaintexts with a better score than that.

3) Any descriptions which can help me understand, compile, run, and verify your answers. (FYI: I check every programming assignment turned in!)
The algorithm is decribed in main.py (line 53+).
It relies on
    - decoding as implemented in the class Cipher (see cipher.py)
    - scoring of plaintext results as implemented in the class QgramDistr (see qgram.py).

The algorithm idea is from:
http://www.practicalcryptography.com/cryptanalysis/stochastic-searching/cryptanalysis-simple-substitution-cipher/
The scoring technique is from:
http://www.practicalcryptography.com/cryptanalysis/text-characterisation/quadgrams/

I implemented everything from scratch. The only thing I looked up from that site's implementation is how to score qgrams that do not appear at all
in the english/spanish language sample (in qgram_data), because this wasn't entirely clear to me from the article.