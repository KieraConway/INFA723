import string
plainValues = string.ascii_lowercase
class Cipher:
    """ Create instance holding ciphertext as list of chars.
    Class provides method decode(key)->plainTextList, based on substitution cipher """
    
    def __init__(self, inputFileName):
        with open(inputFileName) as f:
            self.cipherTextList = list(f.read().lower())
    
    def decode(self, key):
        """ This might be faster than storing key as hashtable<alphabetChar, substChar> (i.e. as dict).
        In any way, for performance reasons it is critical to do the whole algorithm&decoding on DEcryption key
        (i.e. the mapping encryptionAlphabet -> plainTextAlphabet mapping, not the other way around.)
        If in the end we want the ENcryption key, we can use the invertKey() method. """
        return [key[ord(ch)-0x61] if ch.isalpha() else ch for ch in self.cipherTextList]

    def reverseCipher(self):
        """ Can be used before decryption if we suspect that cipherText was reversed """
        self.cipherTextList.reverse()

    @staticmethod
    def invertKey(key):
        """ Key maps encrypted key to plaintext key. This function inverts this mapping to a normal encryption key. """
        invertedKey = [0 for i in range(len(key))]
        for i, ch in enumerate(key):
            invertedKey[ord(ch)-0x61] = chr(0x61+i)
        return invertedKey

# # The following code was just for testing
# if __name__ == "__main__":
#     import random
#     import string
#     orgKey = list(string.ascii_lowercase)
#     print(orgKey)
#     maxKey = orgKey.copy()
#     # random.shuffle(maxKey)
#     print(maxKey)
#     cipherText = Cipher("cipher_input/cipherInp1.txt")
    
#     print(cipherText.cipherTextList)
#     print(cipherText.decode(maxKey))